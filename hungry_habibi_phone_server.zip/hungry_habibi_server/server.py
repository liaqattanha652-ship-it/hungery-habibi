import json, secrets, socket
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB_FILE = BASE / "database.json"

def load_db():
    return json.loads(DB_FILE.read_text(encoding="utf-8"))

def save_db(db):
    DB_FILE.write_text(json.dumps(db, indent=2), encoding="utf-8")

def reply(h, data, status=200):
    raw = json.dumps(data).encode()
    h.send_response(status)
    h.send_header("Content-Type", "application/json; charset=utf-8")
    h.send_header("Cache-Control", "no-store")
    h.send_header("Access-Control-Allow-Origin", "*")
    h.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    h.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
    h.end_headers()
    h.wfile.write(raw)

def fail(h, msg, status=400):
    reply(h, {"error": msg}, status)

def body(h):
    n = int(h.headers.get("Content-Length", "0"))
    return json.loads(h.rfile.read(n) or b"{}")

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(BASE), **kw)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        db = load_db()

        if u.path == "/api/health":
            return reply(self, {"ok": True, "service": "Hungry Habibi API"})

        if u.path == "/api/tables":
            search = q.get("search", [""])[0].lower()
            status = q.get("status", ["all"])[0]
            out = []
            for t in db["tables"]:
                b = next((x for x in db["bookings"] if x["id"] == t.get("bookingId")), None)
                hay = f"table {t['id']} {t['id']} {t['status']} {b['id'] if b else ''} {b['name'] if b else ''} {b.get('phone','') if b else ''}".lower()
                if (not search or search in hay) and (status == "all" or t["status"] == status):
                    x = dict(t); x["booking"] = b; out.append(x)
            return reply(self, {"tables": out})

        if u.path == "/api/bookings":
            search = q.get("search", [""])[0].lower()
            out = [b for b in db["bookings"]
                   if not search or search in " ".join(map(str, b.values())).lower()]
            return reply(self, {"bookings": out})

        return super().do_GET()

    def do_POST(self):
        u = urlparse(self.path).path
        b = body(self)

        if u == "/api/manager/login":
            if b.get("username") == "manager" and b.get("password") == "1234":
                return reply(self, {"accessToken": "server-manager", "role": "manager"})
            return fail(self, "Invalid manager login", 401)

        if u == "/api/bookings":
            db = load_db()
            try:
                tid, guests = int(b["tableId"]), int(b["guests"])
            except Exception:
                return fail(self, "Invalid table or guest count")
            t = next((x for x in db["tables"] if x["id"] == tid), None)
            if not t: return fail(self, "Table not found", 404)
            if t["status"] != "available": return fail(self, "That table is no longer available")
            if guests > t["capacity"]: return fail(self, "Table capacity exceeded")
            name, time = str(b.get("name","")).strip(), str(b.get("time","")).strip()
            if not name or guests < 1 or not time: return fail(self, "Name, guests and time are required")

            used = {x["id"] for x in db["bookings"]}
            while True:
                bid = "HH-" + str(secrets.randbelow(9000) + 1000)
                if bid not in used: break

            booking = {"id": bid, "name": name, "phone": str(b.get("phone","")).strip(),
                       "guests": guests, "tableId": tid, "time": time, "status": "confirmed"}
            db["bookings"].append(booking)
            t["status"], t["bookingId"] = "reserved", bid
            save_db(db)
            return reply(self, {"booking": booking}, 201)

        return fail(self, "API route not found", 404)

    def auth(self):
        return self.headers.get("Authorization") == "Bearer server-manager"

    def do_PATCH(self):
        if not self.auth(): return fail(self, "Authentication required", 401)
        u = urlparse(self.path).path
        if u.startswith("/api/tables/"):
            try: tid = int(u.rstrip("/").split("/")[-1])
            except: return fail(self, "Invalid table id")
            b = body(self); status = b.get("status")
            if status not in ("available","reserved","occupied"): return fail(self, "Invalid status")
            db = load_db()
            t = next((x for x in db["tables"] if x["id"] == tid), None)
            if not t: return fail(self, "Table not found", 404)
            t["status"] = status
            if status == "available":
                if t.get("bookingId"):
                    old = next((x for x in db["bookings"] if x["id"] == t["bookingId"]), None)
                    if old: old["status"] = "completed"
                t["bookingId"] = None
            save_db(db)
            return reply(self, {"table": t})
        return fail(self, "API route not found", 404)

    def do_DELETE(self):
        if not self.auth(): return fail(self, "Authentication required", 401)
        u = urlparse(self.path).path.rstrip("/")
        if u.startswith("/api/bookings/"):
            bid = unquote(u.split("/")[-1]); db = load_db()
            b = next((x for x in db["bookings"] if x["id"] == bid), None)
            if not b: return fail(self, "Booking not found", 404)
            t = next((x for x in db["tables"] if x["id"] == b["tableId"]), None)
            if t: t["status"], t["bookingId"] = "available", None
            b["status"] = "cancelled"; save_db(db)
            return reply(self, {"ok": True})
        return fail(self, "API route not found", 404)

def ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8",80)); return s.getsockname()[0]
    except: return "127.0.0.1"
    finally: s.close()

if __name__ == "__main__":
    port=8000
    print("\nHUNGRY HABIBI SERVER")
    print("PC:    http://localhost:8000")
    print("PHONE: http://" + ip() + ":8000")
    print("\nKeep this window open. Connect phone and PC to the same Wi-Fi.")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
